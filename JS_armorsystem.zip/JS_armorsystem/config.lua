Config = {}

Config.Armours = {
    {
        title = "Light Armour",
        armour = 25,
        time = 3000
    },
    {
        title = "Medium Armour",
        armour = 50,
        time = 4000
    },
    {
        title = "Heavy Armour",
        armour = 100,
        time = 5000
    }
}