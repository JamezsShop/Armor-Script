local function putOnArmour(amount, time)

    local success = lib.progressCircle({
        duration = time,
        label = 'Putting on armour...',
        position = 'bottom',
        useWhileDead = false,
        canCancel = true,
        disable = {
            car = true,
            move = true,
            combat = true
        },
        anim = {
            dict = 'clothingshirt',
            clip = 'try_shirt_positive_d'
        }
    })

    if success then
        SetPedArmour(PlayerPedId(), amount)
    end

end


lib.registerContext({
    id = 'trunk_armour_menu',
    title = 'Grab Armour',
    options = {

        {
            title = 'Light Armour',
            icon = 'shield',
            onSelect = function()
                putOnArmour(25, 3000)
            end
        },

        {
            title = 'Medium Armour',
            icon = 'shield-halved',
            onSelect = function()
                putOnArmour(50, 4000)
            end
        },

        {
            title = 'Heavy Armour',
            icon = 'shield',
            onSelect = function()
                putOnArmour(100, 5000)
            end
        }

    }
})


local function searchTrunk(vehicle)

    local ped = PlayerPedId()

    SetVehicleDoorOpen(vehicle, 5, false, false)

    local success = lib.progressCircle({
        duration = 2500,
        label = 'Searching trunk...',
        position = 'bottom',
        useWhileDead = false,
        canCancel = false,
        disable = {
            car = true,
            move = true,
            combat = true
        },
        anim = {
            dict = 'mini@repair',
            clip = 'fixing_a_player'
        }
    })

    if success then
        lib.showContext('trunk_armour_menu')
    end

end


CreateThread(function()

    exports.ox_target:addGlobalVehicle({

        {
            name = 'grab_armour_trunk',
            icon = 'fa-solid fa-shield',
            label = 'Grab Armour',
            bones = { 'boot' },
            distance = 2.5,

            onSelect = function(data)

                local vehicle = data.entity

                searchTrunk(vehicle)

            end
        }

    })

end)