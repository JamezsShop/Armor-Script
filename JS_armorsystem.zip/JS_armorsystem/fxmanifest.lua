fx_version 'cerulean'
game 'gta5'

author 'JamezShop'
description 'Trunk Armour Script'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

client_scripts {
    'client.lua'
}

dependencies {
    'ox_lib',
    'ox_target'
}